import SwiftUI

@main
struct CoolApp: App {
    var body: some Scene {
        WindowGroup {
            AppBox()
        }
    }
}
